package com.cts.ac.pupperpals.pupperpalspt4.controller;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.ac.pupperpals.pupperpalspt4.service.PupperService;

@Controller
public class HomeController {
	
	
	private PupperService service;
	@Inject
	public void setService(PupperService service) {
		this.service = service;
	}

	@RequestMapping(value= {"/hello"})
	public ModelAndView hello(@RequestParam(required=false, defaultValue="World") String name) {
		ModelAndView ret = new ModelAndView("home");
		// Adds an objet to be used in home.jsp
		ret.addObject("name", service.getBreeds());
		return ret;
	}
}
