package com.cts.ac.pupperpals.pupperpalspt4.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ac.pupperpals.pupperpalspt4.dao.PupperDao;
import com.cts.ac.pupperpals.pupperpalspt4.dto.AddPupperDto;
import com.cts.ac.pupperpals.pupperpalspt4.dto.Breed;
import com.cts.ac.pupperpals.pupperpalspt4.dto.Pupper;


public class PupperServiceImpl implements PupperService {
	
	PupperDao dao;
	
	@Inject
	public void setDao(PupperDao dao) {
		this.dao = dao;
	}
	
	public PupperServiceImpl() {
		System.out.println("Service Created");
	}


	@Override
	public Pupper addPupper(AddPupperDto pupData) {
		return null;
	}
	
	@Override
	public List<Pupper> findPuppersByBreedName(String breedName) {
		return null;
	}
	
	@Override
	public List<Pupper> findAllPuppers() {

		return null;
	}
	
	@Override
	public boolean adoptPupper(Pupper pupper) {
		return false;
	}
	
	@Override
	public List<Breed> getBreeds() {
		return dao.getBreeds();
	}

	@Override
	public Pupper getPupperById(int id) {
		
		return dao.getPupperById(id);
	}

	@Override
	public Breed getBreedById(int id) {
		
		return dao.getBreedById(id);
	}
	
	
}
