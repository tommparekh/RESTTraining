package com.cts.ac.pupperpals.pupperpalspt4.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.ac.pupperpals.pupperpalspt4.dto.AddPupperDto;
import com.cts.ac.pupperpals.pupperpalspt4.dto.Breed;
import com.cts.ac.pupperpals.pupperpalspt4.dto.Pupper;



public interface PupperService {
	
	public Pupper getPupperById(int id);
	
	public Breed getBreedById(int id);

	public Pupper addPupper(AddPupperDto pupData);

	public List<Pupper> findPuppersByBreedName(String breedName);

	public List<Pupper> findAllPuppers();

	public boolean adoptPupper(Pupper pupper);

	public List<Breed> getBreeds();

}