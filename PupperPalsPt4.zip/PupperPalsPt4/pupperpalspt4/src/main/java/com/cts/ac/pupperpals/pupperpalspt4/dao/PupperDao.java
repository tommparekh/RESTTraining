package com.cts.ac.pupperpals.pupperpalspt4.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.cts.ac.pupperpals.pupperpalspt4.dto.Breed;
import com.cts.ac.pupperpals.pupperpalspt4.dto.Pupper;


public interface PupperDao {

	public Pupper getPupperById(int id);
	
	public Breed getBreedById(int id);
	
	public List<Breed> getBreeds();
}
