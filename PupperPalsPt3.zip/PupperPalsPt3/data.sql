INSERT INTO breed (name, temperament, coat) 
VALUES ("Boxer", "Alert, patient, playful, wary of strangers", "Short, shiny, smooth, and tight");

INSERT INTO breed (name, temperament, coat) 
VALUES ("Bichon Frise", "Cheerful, gentle, affectionate", "Soft undercoat; coarse, curley outercoat");

INSERT INTO breed (name, temperament, coat) 
VALUES ("Siberian Husky", "Friendly, gentle, alert, outgoing", "Double, medium length");

INSERT INTO PUPPER (name, sex, weight, height, color, date_of_birth, breed_id)
VALUES ("Lexi", 'F', 58, 22, "Brown with Black", "20130418", 1);

INSERT INTO PUPPER (name, sex, weight, height, color, date_of_birth, breed_id)
VALUES ("Bruno", 'M', 12, 12, "White", "20170410", 2);

INSERT INTO PUPPER (name, sex, weight, height, color, date_of_birth, breed_id)
VALUES ("Socks", 'F', 45, 25, "Grey and WHite", "20180908", 3);

INSERT INTO PUPPER (name, sex, weight, height, color, date_of_birth, breed_id)
VALUES ("Spike", 'm', 10, 11, "White", "20160328", 2);

INSERT INTO PUPPER (name, sex, weight, height, color, date_of_birth, breed_id)
VALUES ("Ali", 'M', 62, 23, "Brown with white", "20150812", 1);
