package com.cts.ac.pupperpals.view;

import com.cts.ac.pupperpals.controller.PupperController;

public interface Runner {
	public void run(PupperController c);
}
